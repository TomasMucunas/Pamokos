import React, { useEffect, useState } from "react";
import axios from "axios";

const Home = () => {
  const [menu, setMenu] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/menu")
      .then((response) => {
        setMenu(response.data);
      })
      .catch((error) => {
        console.error("Error fetching menu:", error);
      });
  }, []);

  return (
    <div>
      <h1>Menu</h1>
      <ul>
        {menu.map((item) => (
          <li key={item.id}>
            {item.title} - {item.description} ({item.quantity} available)
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Home;
