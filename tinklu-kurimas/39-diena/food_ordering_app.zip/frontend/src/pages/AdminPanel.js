import React, { useState, useEffect } from "react";
import axios from "axios";

const AdminPanel = () => {
  const [menu, setMenu] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [quantity, setQuantity] = useState("");

  useEffect(() => {
    fetchMenu();
  }, []);

  const fetchMenu = async () => {
    try {
      const response = await axios.get("http://localhost:5000/api/menu");
      setMenu(response.data);
    } catch (error) {
      console.error("Error fetching menu:", error);
    }
  };

  const addItem = async () => {
    try {
      await axios.post("http://localhost:5000/api/menu", { title, description, quantity });
      fetchMenu();
    } catch (error) {
      console.error("Error adding item:", error);
    }
  };

  return (
    <div>
      <h1>Admin Panel</h1>
      <h2>Add Item</h2>
      <input type="text" placeholder="Title" onChange={(e) => setTitle(e.target.value)} />
      <input type="text" placeholder="Description" onChange={(e) => setDescription(e.target.value)} />
      <input type="number" placeholder="Quantity" onChange={(e) => setQuantity(e.target.value)} />
      <button onClick={addItem}>Add</button>

      <h2>Menu Items</h2>
      <ul>
        {menu.map((item) => (
          <li key={item.id}>
            {item.title} - {item.description} ({item.quantity} available)
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminPanel;
