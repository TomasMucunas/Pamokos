const express = require('express');
const menu = require('../models/menu');

const router = express.Router();

router.get('/', async (req, res) => {
    const menu = await Menu.findAll();
    res.json(menu);
});

router.post('/', async (req, res) => {
    const { title, description, quantity } = req.body;
    try {
        const newItem = await Menu.create({ title, description, quantity });
        res.json(newItem);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

module.exports = router;
