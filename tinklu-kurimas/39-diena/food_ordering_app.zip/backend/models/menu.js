const { Sequelize, DataTypes } = require('sequelize');
const sequelize = require('../config/db');

const menu = sequelize.define('Menu', {
    id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
    title: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.STRING },
    quantity: { type: DataTypes.INTEGER, allowNull: false }
});

module.exports = menu;
